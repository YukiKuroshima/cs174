# AWS host URL
http://ec2-13-57-188-146.us-west-1.compute.amazonaws.com/
